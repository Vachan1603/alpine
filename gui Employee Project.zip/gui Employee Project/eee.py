import subprocess as sp
sp.Popen(['notepad.exe','hello.txt'])
